import 'package:flutter/material.dart';
import 'dart:math';

class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  int r = 1;
  @override
  Widget build(BuildContext context) {
    void roll() {
      setState(() {
        r = Random().nextInt(6) + 1;
      });
    }

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [Colors.purple, Colors.deepOrangeAccent],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                ("assets/dice-${r}.png"),
                width: 200,
              ),
              TextButton(
                  style: TextButton.styleFrom(
                      fixedSize: Size(200, 20),
                      backgroundColor: Colors.blueGrey,
                      foregroundColor: Colors.white),
                  onPressed: roll,
                  child: Text('Roll'))
            ],
          ),
        ),
      ),
    );
  }
}
